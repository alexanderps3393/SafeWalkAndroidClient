package edu.purdue.del;

public interface StartOverCallbackListener {
	public void onStartOver();
}
