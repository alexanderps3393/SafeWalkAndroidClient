package edu.purdue.del;

public interface SubmitCallbackListener {
	
	public void onSubmit();

}
